import React from 'react';

const ShineCollection: React.FC = () => {
  const collections = [
    {
      id: 1,
      title: 'CREATIVE',
      imgUrl: 'https://ext.same-assets.com/3113942737/1826701153.jpeg',
      link: '/shine-collection/creative',
    },
    {
      id: 2,
      title: 'K-PERM',
      imgUrl: 'https://ext.same-assets.com/349203236/1903695528.jpeg',
      link: '/shine-collection/k-perm',
    },
    {
      id: 3,
      title: 'BAD BOY',
      imgUrl: 'https://ext.same-assets.com/3089945441/1569347642.jpeg',
      link: '/shine-collection/bad-boy',
    },
  ];

  return (
    <section className="py-10 bg-white border-t border-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-xl font-bold text-[#2c3856] mb-1">Shine Collection</h2>
        <p className="text-sm text-gray-600 mb-6">'Vibe' nào cũng tỏa sáng</p>

        <div className="grid grid-cols-3 gap-4">
          {collections.map((collection) => (
            <div key={collection.id} className="rounded-md overflow-hidden shadow-sm">
              <div className="relative">
                <a href={collection.link} className="block aspect-w-1 aspect-h-1">
                  <img
                    src={collection.imgUrl}
                    alt={collection.title}
                    className="w-full h-full object-cover"
                  />

                  {/* Dark overlay at bottom */}
                  <div className="absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-black/80 to-transparent"></div>

                  {/* Collection title */}
                  <div className="absolute bottom-0 left-0 right-0 p-2">
                    <h3 className="text-sm font-medium text-white">{collection.title}</h3>
                  </div>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ShineCollection;
