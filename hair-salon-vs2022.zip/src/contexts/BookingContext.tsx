import React, { createContext, useContext, useState, ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';

interface BookingContextType {
  focusBookingForm: () => void;
}

const BookingContext = createContext<BookingContextType | undefined>(undefined);

export const useBooking = () => {
  const context = useContext(BookingContext);
  if (context === undefined) {
    throw new Error('useBooking must be used within a BookingProvider');
  }
  return context;
};

interface BookingProviderProps {
  children: ReactNode;
}

export const BookingProvider: React.FC<BookingProviderProps> = ({ children }) => {
  const navigate = useNavigate();

  const focusBookingForm = () => {
    // Navigate to home page if not there
    navigate('/');

    // Use setTimeout to ensure navigation completes before scrolling
    setTimeout(() => {
      const bookingInput = document.getElementById('booking-phone-input');
      if (bookingInput) {
        // Scroll to the element
        bookingInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
        // Focus on the input field
        (bookingInput as HTMLInputElement).focus();
      }
    }, 100);
  };

  const value = {
    focusBookingForm,
  };

  return (
    <BookingContext.Provider value={value}>
      {children}
    </BookingContext.Provider>
  );
};

export default BookingContext;
