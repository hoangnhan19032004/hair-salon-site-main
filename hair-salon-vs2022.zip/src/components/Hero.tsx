import React, { useState } from 'react';

const Hero: React.FC = () => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [error, setError] = useState('');

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPhoneNumber(e.target.value);
    if (e.target.value) {
      setError('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!phoneNumber.trim()) {
      setError('Vui lòng nhập số điện thoại của bạn');
      return;
    }

    // Process the booking
    console.log('Booking with phone number:', phoneNumber);
    // Here you would typically make an API call to submit the booking

    // Reset after successful submission
    setPhoneNumber('');
  };

  return (
    <section className="relative bg-[#e9eef6] overflow-hidden min-h-[500px] flex items-center">
      <div className="container mx-auto px-4 py-12 relative z-10">
        <div className="flex justify-center">
          <div className="w-full max-w-xl text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-[#2c3856] mb-6">
              STYLE LOOK
            </h1>
            <p className="text-lg text-gray-700 mb-8 mx-auto max-w-lg">
              Đặt lịch tiện lợi và dễ dàng để tận hưởng trải nghiệm làm đẹp thế hệ mới với chất lượng uy tín.
              Được các ngôi sao và người nổi tiếng tin tưởng thường xuyên lựa chọn.
            </p>

            {/* Appointment booking */}
            <div className="bg-white p-4 rounded-md shadow-md mx-auto max-w-md" id="booking-form">
              <h3 className="text-center text-[#2c3856] font-semibold mb-4">
                Đặt lịch gọi đầu chỉ 30 giây
              </h3>
              <form onSubmit={handleSubmit}>
                <div className="flex mb-2">
                  <input
                    id="booking-phone-input"
                    type="tel"
                    value={phoneNumber}
                    onChange={handlePhoneChange}
                    placeholder="Nhập số điện thoại của bạn"
                    required
                    className={`flex-1 px-4 py-2 border ${error ? 'border-red-500' : 'border-gray-300'} rounded-l-md focus:outline-none focus:ring-2 focus:ring-[#2c3856]`}
                  />
                  <button
                    type="submit"
                    className="bg-[#2c3856] hover:bg-[#4a5b89] text-white px-4 py-2 rounded-r-md transition-colors"
                  >
                    Đặt lịch ngay
                  </button>
                </div>
                {error && (
                  <p className="text-red-500 text-xs mb-2">{error}</p>
                )}
                <p className="text-sm text-gray-500 text-center">
                  Cắt xong trả tiền, hủy lịch không sao
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
