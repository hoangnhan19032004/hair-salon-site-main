import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import SpaRelax from './components/SpaRelax';
import ShineCollection from './components/ShineCollection';
import Footer from './components/Footer';
import BookingButton from './components/BookingButton';
import GoiMassageDetail from './pages/GoiMassageDetail';
import LayRayTaiDetail from './pages/LayRayTaiDetail';
import DichVuTocDetail from './pages/DichVuTocDetail';
import UonDinhHinhDetail from './pages/UonDinhHinhDetail';
import ThayDoiMauTocDetail from './pages/ThayDoiMauTocDetail';
import { BookingProvider } from './contexts/BookingContext';

function App() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 100) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);

    // Clean up the event listener on component unmount
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const handleOpenRegister = () => {
    // This will be handled by the Header component
    // We'll dispatch a custom event that the Header can listen to
    const event = new CustomEvent('openRegisterModal');
    window.dispatchEvent(event);
  };

  const HomePage = () => (
    <div className="relative font-segoe">
      <Header isScrolled={isScrolled} />
      <main className="pt-16">
        <Hero />
        <Services />
        <SpaRelax />
        <ShineCollection />
      </main>
      <BookingButton />
      <Footer onOpenRegister={handleOpenRegister} />
    </div>
  );

  return (
    <Router>
      <BookingProvider>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/dich-vu-goi-massage-relax-detail" element={<GoiMassageDetail />} />
          <Route path="/dich-vu-lay-ray-tai-mui-detail" element={<LayRayTaiDetail />} />
          <Route path="/dich-vu-cat-toc" element={<DichVuTocDetail />} />
          <Route path="/dich-vu-uon-nhuom-duong-toc" element={<UonDinhHinhDetail />} />
          <Route path="/dich-vu-uon-nhuom-duong-toc#nhuom-toc" element={<ThayDoiMauTocDetail />} />
          <Route path="/dich-vu-thay-doi-mau-toc" element={<ThayDoiMauTocDetail />} />
        </Routes>
      </BookingProvider>
    </Router>
  );
}

export default App;
