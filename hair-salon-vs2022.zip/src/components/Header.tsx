import React, { useState, useEffect } from 'react';
import HairLogo from '../assets/hairLogo';
import LoginForm from './LoginForm';
import RegisterForm from './RegisterForm';

interface HeaderProps {
  isScrolled: boolean;
}

const Header: React.FC<HeaderProps> = ({ isScrolled }) => {
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);

  useEffect(() => {
    // Listen for the custom event to open the register modal
    const handleOpenRegisterEvent = () => {
      openRegisterModal();
    };

    window.addEventListener('openRegisterModal', handleOpenRegisterEvent);

    // Clean up event listener
    return () => {
      window.removeEventListener('openRegisterModal', handleOpenRegisterEvent);
    };
  }, []);

  const openLoginModal = () => {
    setIsLoginModalOpen(true);
    setIsRegisterModalOpen(false);
  };

  const closeLoginModal = () => {
    setIsLoginModalOpen(false);
  };

  const openRegisterModal = () => {
    setIsRegisterModalOpen(true);
    setIsLoginModalOpen(false);
  };

  const closeRegisterModal = () => {
    setIsRegisterModalOpen(false);
  };

  const switchToRegister = () => {
    setIsLoginModalOpen(false);
    setIsRegisterModalOpen(true);
  };

  const switchToLogin = () => {
    setIsRegisterModalOpen(false);
    setIsLoginModalOpen(true);
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled ? 'bg-white shadow-md' : 'bg-transparent'
        }`}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center">
              <a href="/" className="flex items-center">
                <HairLogo className="h-10" />
              </a>
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex">
              <ul className="flex space-x-6">
                <li>
                  <a href="/" className="text-[#2c3856] hover:text-[#4a5b89] font-medium">
                    Trang chủ
                  </a>
                </li>
                <li>
                  <a href="/about" className="text-[#2c3856] hover:text-[#4a5b89] font-medium">
                    Về chúng tôi
                  </a>
                </li>
                <li>
                  <a href="/shop" className="text-[#2c3856] hover:text-[#4a5b89] font-medium">
                    Cửa hàng
                  </a>
                </li>
                <li>
                  <a href="/locations" className="text-[#2c3856] hover:text-[#4a5b89] font-medium">
                    Tìm salon gần nhất
                  </a>
                </li>
              </ul>
            </nav>

            {/* Login Button & Register Button */}
            <div className="hidden md:flex items-center space-x-3">
              <button
                onClick={openLoginModal}
                className="bg-[#2c3856] hover:bg-[#4a5b89] text-white py-2 px-4 rounded-md transition-colors"
              >
                Đăng nhập
              </button>
              <button
                onClick={openRegisterModal}
                className="border border-[#2c3856] text-[#2c3856] hover:bg-[#2c3856] hover:text-white py-2 px-4 rounded-md transition-colors"
              >
                Đăng ký
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button className="text-[#2c3856]">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Login and Register Modals */}
      <LoginForm
        isOpen={isLoginModalOpen}
        onClose={closeLoginModal}
        onSwitchToRegister={switchToRegister}
      />
      <RegisterForm
        isOpen={isRegisterModalOpen}
        onClose={closeRegisterModal}
        onSwitchToLogin={switchToLogin}
      />
    </>
  );
};

export default Header;
